## Functions to generate the models used in MRSP.
## Wolfgang P��necker, last modified: 23.03.2016, 21:10

MRSP.model <- function(transformDat, backtransformDat, invlink, link, logl, loglik, gradient, fisher,
                       constraint, check, sancheck, name = "user-specified",
                       comment = "user-specified"){
  ## Purpose: Generates models to be used for the MRSP package.
  ## ----------------------------------------------------------------------
  ## Arguments: in general, the functions take a generic data argument dat with
  ##            slots depending on the particular model and its data structure.
  ##            for MRSP, we need a list with elements "y", "x" and "V"
  ## 
  ## transformDat: a function with argument "dat" that implements a transforma-
  ##            tion of the data objects in "dat" to be applied at the beginning
  ##            of each fista call. used, for example, for sequential logit
  ##            models to be able to handle discrete survival cases with cen-
  ##            soring.
  ## backtransformDat: a function with argument "dat" that undos whatever trans-
  ##            formation was performed in 'transformDat'.
  ## invlink:   a function with arguments "eta" implementing the inverse link
  ##            function. eta must be a matrix of size nobs * K for K response
  ##            categories.
  ## link:      a function with arguments "mu" and "constr" implementing the link
  ##            function for the various options of the constraint in "constr". 
  ## logl:      a function with arguments "y" and "mu" implementing
  ##            the log-likelihood contribution of each observation.  weights
  ##            must be a vector of length nobs. output is nobs x 1.
  ## loglik:    a function with arguments "y", "mu" and "weights"
  ##            implementing the log-likelihood function. weights must be a
  ##            vector of length nobs.
  ## gradient:  a function with arguments "x", "V", "y", "mu", "eta", "coef", "weights",
  ##            "penweights", "grpindex" and "Proximal.args" implementing the
  ##            gradient of the log-likelihood function. returns a list with two
  ##            elements, the first one being a K x p matrix that belongs to the
  ##            global predictors in x and the second a K x L matrix belonging
  ##            to the L category-specific predictors in V. x must be an nobs*p
  ##            matrix, V a list of length K with entries that are nobs x L
  ##            matrices. y must be a nobs x K matrix.
  ## fisher :   a function with arguments "x", "V", "mu" and "weights"
  ##            implementing the  hessian of the log-likelihood. same arguments
  ##            as above, returns a fisher matrix of size (K*p + K*L) x (K*p + L)
  ## constraint: the default constraint to use with the respective model class.
  ## sancheck:  a function with arguments "mu", "eta" and "weights" that checks
  ##            whether the fit converges towards a degenerated 0-1-separation. 
  ## name:      a character name

  RET <- new("MRSP.model",
           transformDat = transformDat,
           backtransformDat = backtransformDat,
           invlink    = invlink,
           link       = link,
           logl       = logl,
           loglik     = loglik,
           gradient   = gradient,
           fisher     = fisher,
           constraint = constraint,
           name       = name,
           check      = check,
           sancheck   = sancheck,
           comment    = comment)
   RET
}



## the model used for this package:
multinomlogit <- function(){
  MRSP.model(transformDat = function(dat){dat},
             backtransformDat = function(dat){dat}, 
             invlink  = cmpfun(function(eta){
                         m <- maxRow(eta)
                         eeta <- exp(eta - m)
                         mu <- eeta / rowSums(eeta)
                         return(mu)
                        }),
             link     = cmpfun(function(mu, constr){
                         if(constr == "none"){
                          eta <- log(mu)
                         }else{
                          if(is.numeric(constr)){
                           mu.ref <- mu[,constr, drop=T]
                          }else if(constr == "symmetric"){
                           mu.ref <- apply(mu, 1, function(u) exp(mean(log(u))))
                          }    
                          eta <- log(mu / mu.ref)
                         }
                         return(eta)
                        }),
             logl     = cmpfun(function(y, mu, ...){
                         mu[which(mu <= 1e-6)] <- 1e-8
                         mu[which(mu >= 1 - 1e-6)] <- 1 - 1e-8
                         out <- rowSums(y * log(mu))
                         return(out)
                        }),
             loglik   = cmpfun(function(y, mu, weights, ...){
                         mu[which(mu <= 1e-6)] <- 1e-8
                         mu[which(mu >= 1 - 1e-6)] <- 1 - 1e-8
                         out <- sum(weights * y * log(mu))
                         return(out)
                        }),
             gradient = cmpfun(function(dat, mu, eta, coef, weights, penweights,
                                        grpindex, Proximal.args, ...){
                         constr <- Proximal.args$constraint
                         indg <- Proximal.args$indg
                         indcs <- Proximal.args$indcs
                         grad <- list()
                         grad[[1]] <- crossprod((dat$y - mu), weights * dat$x)
                         if(is.numeric(constr)) grad[[1]][constr,] <- 0
                         ## maybe mean-centering is necessary for constr 'symmetric', but probably not...
                         names(grad)[[1]] <- "global"
                         if(Proximal.args$hasV){
                          grad[[2]] <- matrix(nrow=ncol(dat$y), ncol=ncol(dat$V[[1]]))
                          if(length(indg) > 0){
                           gradg <- crossprod(c(dat$y - mu), rep(weights, times=ncol(dat$y)) * do.call("rbind", dat$V))[,indg]
                           grad[[2]][,indg] <- matrix(rep(gradg, ncol(dat$y)), nrow=ncol(dat$y), byrow=T)
                          }
                          if(length(indcs > 0)){
                           grad[[2]][,indcs] <- (t(mapply(crossprod, as.list(as.data.frame(dat$y - mu)), dat$V)))[,indcs]
                          }
                          names(grad)[[2]] <- "cat-specific"
                         }
                         return(grad)
                        }),
             fisher   = cmpfun(function(dat, mu, weights, Proximal.args, ...){
                         warning(paste("Fisher matrix needs rework and can't be used for the moment"))
                         #Fisher <- 0
                         #for(i in seq_len(nrow(dat$y))){
                         # sigmai <- diag(mu[i,]) - mu[i,] %*% t(mu[i,])
                         # Xi <- t(diag(ncol(mu)) %x% dat$x[i,])
                         # if(!is.null(dat$V)){Xi <- cbind(Xi, dat$V[[i]])}
                         # Fisher <- Fisher + crossprod(Xi, weights[i] * sigmai %*% Xi)
                         #}
                         #return(Fisher)
                        }),
             constraint = "symmetric",
             check    = function(dat){all(dat$y >= 0) & all(dat$y <= 1)},
             sancheck = function(coef, coef.old2, mu, eta, weights, Proximal.args){
                         if(Proximal.args$ridgestabil == T){Proximal.args$do.sancheck <<- F}
                         if(mean(abs(do.call("c", lapply(coef, "c")))) > mean(abs(do.call("c", lapply(coef.old2, "c"))))){
                          Proximal.args$sancount <<- Proximal.args$sancount + 1
                         }else{Proximal.args$sancount <<- 0}
                         if((mean(abs(do.call("c", lapply(coef, "c")))) > 5) & (Proximal.args$sancount > 5)){
                          if(!Proximal.args$ridgestabil){
                           warning(paste("The specified model seems to allow for a perfect separation of the response categories. A small ridge penalty was added to prevent diverging coefficients."))
                          } 
                          Proximal.args$ridgestabil <<- T
                          Proximal.args$ridgestabilrf <<- T
                          Proximal.args$do.sancheck <<- F
                         }
                        },
             name     = "Multinomial Logit Model",
             comment  = "Here y denotes the scaled response (i.e. y in [0,1]), if multiple observations of the same covariates are available, they are accounted for by the use of 'weights'"
  )
}


cumulativelogit <- function(){
             link     = cmpfun(function(mu, constr){
                         if(any(mu < -0.01)){
                          print(mu)
                          stop("mu negative in link")
                         }
                         if(any(mu > 1.00)){
                          print(mu)
                          stop("mu larger than one in link")
                         }
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         k <- ncol(mu) 
                         if(all(v.allequal(mu[,k],1))){
                          invmu <- 1-mu
                          eta <- log(mu/invmu)
                         }else{
                          cummu <- rowCumsum(mu)
                          if(all(v.allequal(cummu[,k],1))){
                           cummu <- cummu[,-k]
                           invmu <- 1-cummu
                           eta <- log(cummu/invmu)
                          }else stop("the 'mu'-object supplied to function 'link' does not have the correct format, it must have as many columns as there are response categories!") 
                         }
                         return(eta)
                        })
  MRSP.model(transformDat = function(dat){
                         dat$y <- cbind(dat$y, 1-rowSums(dat$y))
                         return(dat)
                        },
             backtransformDat = function(dat){
                         dat$y <- dat$y[,-ncol(dat$y)]
                         return(dat)
                        }, 
             invlink  = cmpfun(function(eta){
                         lpeta <- log1pexp(eta)
                         if(any(is.na(lpeta))){
                          #print(eta)
                          #print(lpeta)
                          stop("lpeta is NA or NaN in invlink")
                         }
                         if(any(!is.finite(lpeta))){
                          print(lpeta)
                          stop("lpeta wrong in invlink")
                         } 
                         lmu <- eta - lpeta
                         if(any(lmu > 0.01)){
                          print(round(lmu, 4))
                          stop("'lmu' too large in invlink")
                         } 
                         mu <- exp(lmu)
                         mu <- cbind(0, mu, 1)
                         mu <- t(diff(t(mu), lag=1, differences=1))   # this transforms P(Y<=r) to P(Y=r)
                         return(mu)
                        }),
             link     =  link,
             logl     = cmpfun(function(y, mu, ...){
                         #y <- cbind(y, 1-rowSums(y))
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         out <- rowSums(y * log(mu))
                         return(out)
                        }),
             loglik   = cmpfun(function(y, mu, weights, ...){
                         #y <- cbind(y, 1-rowSums(y)) 
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         out <- sum(weights * y * log(mu))
                         return(out)
                        }),
             gradient = cmpfun(function(dat, mu, eta, coef, weights, penweights,
                                        grpindex, Proximal.args, ...){
                         k <- ncol(dat$y)              # due to 'transformDat', dat$y indeed has k columns when function gradient is called
                         q <- k-1
                         gradind <- 1:q
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         nobs <- nrow(dat$y)
                         sl.indg <- Proximal.args$sl.indg
                         sl.indcs <- Proximal.args$sl.indcs
                         indg <- Proximal.args$indg
                         indcs <- Proximal.args$indcs
                         cummu <- rowCumsum(mu)
                         dcummudeta <- cummu * (1-cummu)
                         deta <- dcummudeta[,gradind] * (dat$y[,gradind]/mu[,gradind] - dat$y[,2:k]/mu[,2:k])
                         grad <- list()
                         grad[[1]] <- matrix(0, nrow=q, ncol=ncol(dat$x)) 
                         if(length(sl.indg) > 0){ 
                          gradg1 <- colSums(crossprod(deta, weights * dat$x[,sl.indg])) 
                          grad[[1]][,sl.indg] <- matrix(rep(gradg1, q), nrow=q, byrow=T)
                         }
                         if(length(sl.indcs) > 0){
                          grad[[1]][,sl.indcs] <- crossprod(deta, weights * dat$x[,sl.indcs])                  
                         }
                         names(grad)[[1]] <- "global" 
                         if(Proximal.args$hasV){
                          grad[[2]] <- matrix(nrow=q, ncol=ncol(dat$V[[1]]))
                          if(length(indg) > 0){
                           gradg <- crossprod(c(deta), rep(weights, times=q) * do.call("rbind", dat$V))[,indg]
                           grad[[2]][,indg] <- matrix(rep(gradg, q), nrow=q, byrow=T)
                          }
                          if(length(indcs > 0)){
                           grad[[2]][,indcs] <- (t(mapply(crossprod, as.list(as.data.frame(deta)), dat$V)))[,indcs]
                          }
                          names(grad)[[2]] <- "cat-specific"
                         }
                         return(grad)
                        }),
             fisher   = cmpfun(function(dat, mu, weights, Proximal.args, ...){
                         warning(paste("Fisher matrix needs rework and can't be used for the moment"))
                        }),
             constraint = "none",
             check    = function(dat){all(dat$y[!is.na(dat$y)] >= 0) & all(dat$y[!is.na(dat$y)] <= 1)},
             sancheck = function(coef, coef.old2, mu, eta, weights, Proximal.args){
                         if(Proximal.args$ridgestabil == T){Proximal.args$do.sancheck <<- F}
                         if(mean(abs(do.call("c", lapply(coef, "c")))) > mean(abs(do.call("c", lapply(coef.old2, "c"))))){
                          Proximal.args$sancount <<- Proximal.args$sancount + 1
                         }else{Proximal.args$sancount <<- 0}
                         if((mean(abs(do.call("c", lapply(coef, "c")))) > 5) & (Proximal.args$sancount > 5)){
                          if(!Proximal.args$ridgestabil){
                           warning(paste("The specified model seems to allow for a perfect separation of the response categories. A small ridge penalty was added to prevent diverging coefficients."))
                          } 
                          Proximal.args$ridgestabil <<- T
                          Proximal.args$ridgestabilrf <<- T
                          Proximal.args$do.sancheck <<- F
                         }
                        },
             name     = "Cumulative Logit Model",
             comment  = "Here y denotes the scaled response (i.e. y in [0,1]), if multiple observations of the same covariates are available, they are accounted for by the use of 'weights'")
}



sequentiallogit <- function(){
             link     = cmpfun(function(mu, constr){
                         if(any(mu < -0.01)){
                          print(mu)
                          stop("mu negative in link")
                         }
                         if(any(mu > 1.00)){
                          print(mu)
                          stop("mu larger than one in link")
                         }
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         invmu <- 1-mu
                         eta <- log(mu/invmu)
                         return(eta)
                        })
  MRSP.model(transformDat = function(dat){dat},
             backtransformDat = function(dat){dat}, 
             invlink  = cmpfun(function(eta){
                         lpeta <- log1pexp(eta)
                         if(any(is.na(lpeta))){
                          print(eta)
                          print(lpeta)
                          stop("lpeta is NA or NaN in invlink")
                         }
                         if(any(!is.finite(lpeta))){
                          print(lpeta)
                          stop("lpeta wrong in invlink")
                         } 
                         lmu <- eta - lpeta
                         if(any(lmu > 0.01)){
                          print(round(lmu, 4))
                          stop("'lmu' too large in invlink")
                         } 
                         mu <- exp(lmu)
                         return(mu)
                        }),
             link     =  link,
             logl     = cmpfun(function(y, mu, ...){
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         out <- apply(y*log(mu), 1, function(u){sum(u[!is.na(u)])})
                         out <- out + apply((1-y)*log(1-mu), 1, function(u){sum(u[!is.na(u)])})
                         return(out)
                        }),
             loglik   = cmpfun(function(y, mu, weights, ...){
                         weights <- matrix(rep(weights, times=ncol(y)), ncol=ncol(y))             
                         ind <- !is.na(y)
                         y <- y[ind]      # this already vectorizes y!
                         mu <- mu[ind]
                         weights <- weights[ind]
                         mu[which(mu <= 1e-8)] <- 1e-8
                         mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                         out <- sum(weights * (y*log(mu) + (1-y)*log(1-mu)))
                         return(out)
                        }),
             gradient = cmpfun(function(dat, mu, eta, coef, weights, penweights,
                                        grpindex, Proximal.args, ...){         
                         ## assumption: the original event times (taking integer values between 1 and q) are supplied via entry 'dat$ytimes'. warning: a value of k in the original response must be coded as q here, with censoring...
                         q <- ncol(dat$y)
                         nobs <- nrow(dat$y)
                         sl.indg <- Proximal.args$sl.indg
                         sl.indcs <- Proximal.args$sl.indcs
                         indg <- Proximal.args$indg
                         indcs <- Proximal.args$indcs
                         if(length(sl.indg) > 0 | length(indg) > 0){                         
                          ymax <- rowMaxs(dat$y, na.rm=T)                        ## from package matrixStats
                         } 
                         if(length(sl.indcs) > 0 | length(indcs) > 0){
                          res <- dat$y - mu                                     
                          res[is.na(res)] <- 0 
                         }
                         grad <- list()
                         grad[[1]] <- matrix(0, nrow=q, ncol=ncol(dat$x)) 
                         if(length(sl.indg) > 0){ 
                          eventtimesind <- cbind(seq_len(nobs), dat$ytimes)
                          cummu <- rowCumsum(mu)
                          gradg1 <- crossprod((ymax - cummu[eventtimesind]), weights * dat$x[,sl.indg])
                          grad[[1]][,sl.indg] <- matrix(rep(gradg1, q), nrow=q, byrow=T)
                         }
                         if(length(sl.indcs) > 0){
                          grad[[1]][,sl.indcs] <- crossprod(res, weights * dat$x[,sl.indcs])                  ## contains some maybe unnecessary multiplications with zero, but whatever...
                         }
                         names(grad)[[1]] <- "global" 
                         if(Proximal.args$hasV){
                          grad[[2]] <- matrix(nrow=q, ncol=ncol(dat$V[[1]]))
                          if(length(indg) > 0){
                           Vunzipped <- do.call("rbind", dat$V)[,indg]                 # nobs*q  x  length(indg) matrix #
                           eventind <- seq_len(nobs) + nobs*(dat$ytimes-1)
                           yV <- Vunzipped[eventind,] * ymax
                           Varray <- matlist2array(dat$V)[,indg,]                      # kinda redundant, but doing yV was easier to do with a matrix, Vmucumsum was easier with an array... msg me if you know a better solution...
                           Vmu <- Varray*c(mu)
                           Vmucumsum <- apply(Vmu, 2, rowCumsum)
                           gradg2 <- yV - Vmucumsum[eventind,]
                           grad[[2]][,indg] <- matrix(rep(gradg2, q), nrow=q, byrow=T)
                          }
                          if(length(indcs > 0)){
                           grad[[2]][,indcs] <- (t(mapply(crossprod, as.list(as.data.frame(res)), dat$V)))[,indcs]
                          }
                          names(grad)[[2]] <- "cat-specific"
                         }
                         return(grad)
                        }),
             fisher   = cmpfun(function(dat, mu, weights, Proximal.args, ...){
                         warning(paste("Fisher matrix needs rework and can't be used for the moment"))
                        }),
             constraint = "none",
             check    = function(dat){all(dat$y[!is.na(dat$y)] >= 0) & all(dat$y[!is.na(dat$y)] <= 1)},
             sancheck = function(coef, coef.old2, mu, eta, weights, Proximal.args){
                         if(Proximal.args$ridgestabil == T){Proximal.args$do.sancheck <<- F}
                         if(mean(abs(do.call("c", lapply(coef, "c")))) > mean(abs(do.call("c", lapply(coef.old2, "c"))))){
                          Proximal.args$sancount <<- Proximal.args$sancount + 1
                         }else{Proximal.args$sancount <<- 0}
                         if((mean(abs(do.call("c", lapply(coef, "c")))) > 5) & (Proximal.args$sancount > 5)){
                          if(!Proximal.args$ridgestabil){
                           warning(paste("The specified model seems to allow for a perfect separation of the response categories. A small ridge penalty was added to prevent diverging coefficients."))
                          } 
                          Proximal.args$ridgestabil <<- T
                          Proximal.args$ridgestabilrf <<- T
                          Proximal.args$do.sancheck <<- F
                         }
                        },
             name     = "Sequential Logit Model",
             comment  = "Here y denotes the scaled response (i.e. y in [0,1]), if multiple observations of the same covariates are available, they are accounted for by the use of 'weights'")
}




CUBbinomiallogit <- function(){
  MRSP.model(transformDat = function(dat){dat},
             backtransformDat = function(dat){dat}, 
             invlink  = cmpfun(function(eta){
                         #eeta <- exp(-eta)
                         #mu <- 1 / (1 + eeta)
                         logeta <- eta - log1pexp(eta) # see MRSP-helpers for the definition of log1pexp
                         mu <- exp(logeta)
                         return(mu)
                        }),
             link     = cmpfun(function(mu, constr="none"){
                         if(constr == "none"){
                          eta <- log(mu/(1-mu))
                         }else{
                          stop("constraint must be 'none' for CUBbinomiallogit models")
                         }
                         return(eta)
                        }),
             logl     = cmpfun(function(y, mu, ...){
                         k <- max(y)
                         binomcoefs <- log(choose(k-1, y-1))
                         mu[which(mu <= 1e-6)] <- 1e-8
                         mu[which(mu >= 1 - 1e-6)] <- 1 - 1e-8
                         out <- rowSums( (y-1)*log(1-mu) + (k-y)*log(mu) + binomcoefs )
                         return(out)
                        }),
             loglik   = cmpfun(function(y, mu, weights, ...){
                         k <- max(y)
                         binomcoefs <- log(choose(k-1, y-1))
                         mu[which(mu <= 1e-6)] <- 1e-8
                         mu[which(mu >= 1 - 1e-6)] <- 1 - 1e-8
                         out <- sum(weights*( (y-1)*log(1-mu) + (k-y)*log(mu) + binomcoefs ))
                         return(out)
                        }),
             ## compute the score function. output must be a list for technical reasons.
             ## it is typically of length 1, with the entry being a K x p matrix
             ## in models with p-dimensional predictor dat$x and K-dimensional response
             ## variable dat$y.
             gradient = cmpfun(function(dat, mu, eta, coef, weights, penweights,
                                        grpindex, Proximal.args, ...){
                         constr <- Proximal.args$constraint
                         k <- max(dat$y)
                         grad <- list()
                         grad[[1]] <- crossprod(((k-dat$y) - (k-1)*mu), weights * dat$x)
                         if(constr != "none") stop("constraint must be 'none' for CUBbinomiallogit models")
                         ## maybe mean-centering is necessary for constr 'symmetric', but probably not...
                         names(grad)[[1]] <- "global"
                         if(Proximal.args$hasV){
                          stop("function 'gradient' does currently not support 'V-type' predictors in family CUBbinomiallogit")
                         }
                         return(grad)
                        }),
             fisher   = cmpfun(function(dat, mu, weights, Proximal.args, ...){
                         warning(paste("Fisher matrix needs rework and can't be used at the moment"))
                        }),
             constraint = "none",
             ## the following function checks if all y-values are integers lying between 1 and k.
             check    = function(dat){k <- max(dat$y); all(dat$y %in% seq(from=1, to=k)) },#&& length(table(dat$y)) == k},
             ## NEVER EVER touch the following sanity check function which is used to detect and handle diverging coefficients.
             sancheck = function(coef, coef.old2, mu, eta, weights, Proximal.args){
                         if(Proximal.args$ridgestabil == T){Proximal.args$do.sancheck <<- F}
                         if(mean(abs(do.call("c", lapply(coef, "c")))) > mean(abs(do.call("c", lapply(coef.old2, "c"))))){
                          Proximal.args$sancount <<- Proximal.args$sancount + 1
                         }else{Proximal.args$sancount <<- 0}
                         if((mean(abs(do.call("c", lapply(coef, "c")))) > 5) & (Proximal.args$sancount > 5)){
                          if(!Proximal.args$ridgestabil){
                           warning(paste("The specified model seems to yield divering parameter estimates. A small ridge penalty was added to prevent diverging coefficients."))
                          }
                          Proximal.args$ridgestabil <<- T
                          Proximal.args$ridgestabilrf <<- T
                          Proximal.args$do.sancheck <<- F
                         }
                        },
             name     = "CUB Binomial Logit Model",
             comment  = "Here y takes integer values between 1 and k := max(y)"
  )
}




## the model used for this package:
OLSreg <- function(){
  MRSP.model(transformDat = function(dat){dat},
             backtransformDat = function(dat){dat}, 
             invlink  = cmpfun(function(eta){
                         mu <- eta
                         return(mu)
                        }),
             link     = cmpfun(function(mu, constr){
                         eta <- mu
                         return(eta)
                        }),
             logl     = cmpfun(function(y, mu, ...){
                         out <- -(y - mu)^2
                         return(out)
                        }),
             loglik   = cmpfun(function(y, mu, weights, ...){
                         out <- -sum(weights * (y - mu)^2)
                         return(out)
                        }),
             gradient = cmpfun(function(dat, mu, eta, coef, weights, penweights,
                                        grpindex, Proximal.args, ...){
                         grad <- list()
                         grad[[1]] <- crossprod((dat$y - mu), weights * dat$x)
                         ## maybe mean-centering is necessary for constr 'symmetric', but probably not...
                         names(grad)[[1]] <- "global"
                         return(grad)
                        }),
             fisher   = cmpfun(function(dat, mu, weights, Proximal.args, ...){
                         warning(paste("Fisher matrix needs rework and can't be used for the moment"))
                         #Fisher <- 0
                         #for(i in seq_len(nrow(dat$y))){
                         # sigmai <- diag(mu[i,]) - mu[i,] %*% t(mu[i,])
                         # Xi <- t(diag(ncol(mu)) %x% dat$x[i,])
                         # if(!is.null(dat$V)){Xi <- cbind(Xi, dat$V[[i]])}
                         # Fisher <- Fisher + crossprod(Xi, weights[i] * sigmai %*% Xi)
                         #}
                         #return(Fisher)
                        }),
             constraint = "none",
             check    = function(dat){is.numeric(dat$y)},
             sancheck = function(coef, coef.old2, mu, eta, weights, Proximal.args){
                         if(Proximal.args$ridgestabil == T){Proximal.args$do.sancheck <<- F}
                         if(mean(abs(do.call("c", lapply(coef, "c")))) > mean(abs(do.call("c", lapply(coef.old2, "c"))))){
                          Proximal.args$sancount <<- Proximal.args$sancount + 1
                         }else{Proximal.args$sancount <<- 0}
                         if((mean(abs(do.call("c", lapply(coef, "c")))) > 5) & (Proximal.args$sancount > 5)){
                          if(!Proximal.args$ridgestabil){
                           warning(paste("The specified model seems to allow for a perfect separation of the response categories. A small ridge penalty was added to prevent diverging coefficients."))
                          }
                          Proximal.args$ridgestabil <<- T
                          Proximal.args$ridgestabilrf <<- T
                          Proximal.args$do.sancheck <<- F
                         }
                        },
             name     = "OLS Regression",
             comment  = "Linear OLS Regression. Note that functions 'logl' and 'loglik' are based on the RSS, not the actual loglikelihood! Also note that error variance estimation in penalized models can be subject to substantial bias."
  )
}