MRSPwelcomemessage <- function(){
  cat("-----------------------------",
      "This is MRSP version 0.6.11",
      #"-----------------------------",
      "Author: Wolfgang Poessnecker",
      "Date: March 23, 2016",
      "-----------------------------",
      sep = "\n")   }

.onAttach <- function(libname, pkgname){
  packageStartupMessage(MRSPwelcomemessage())
}
